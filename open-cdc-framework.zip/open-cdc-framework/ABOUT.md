# About this project

> Template — fill in the [bracketed] parts and delete this line before publishing. Keep it factual and concrete: the credibility of this framework rests on it being written by someone who has actually built and run a CDC.

## Why this framework exists

I have worked [10] years in cyber security. I started where many readers of this framework are now: as one of three analysts in an organisation of more than 5,000 employees, spending most of our time on reactive firefighting with little room to address root causes. I later took over as manager, and over the following eighteen months the team developed from that starting point into a process-driven Cyber Defence Center with 24/7/365 in-house monitoring, organised as a capability-based (tierless) SOC rather than a tiered one — analysts own their cases end-to-end. The trade-offs behind that choice are the ones described in [docs/11-operating-models.md](docs/11-operating-models.md), Model C.

I have also served as main or secondary sponsor in SIM3 assessments for national and international CSIRT teams pursuing TF-CSIRT certification [adjust to your exact record — number of teams, years, whether Trusted Introducer-listed sponsor]. Working on the sponsor side of maturity assessments across different teams shaped this framework's emphasis on living documentation, independent verification, and evidence over assertion (see [docs/16-csirt-community.md](docs/16-csirt-community.md)).

Along the way I encountered most of the problems this framework now addresses. Among them:

- [Pitfall 0 — e.g., "as three analysts we treated firefighting as the normal state; the underlying problem was not workload but that no one had the mandate to pause triage long enough to fix root causes"]
- [Pitfall 1 — e.g., "we acquired technology before we had the mandate, and spent a year establishing authority we should have had in writing from the start"]
- [Pitfall 2 — e.g., "we onboarded log sources by what was easy rather than by detection value, and paid for volume that taught us little"]
- [Pitfall 3 — e.g., "our first statutory reporting deadline arrived before our reporting procedure did"]
- [Add the ones that actually occurred — these are the most useful sentences in the repository]

Each of these was avoidable with the kind of structured, practitioner-written guide I was looking for at the time and could not find. This project is an attempt to write it, and to make it freely available so other teams in Europe do not have to learn the same lessons the slow way.

## Who I am

- Name / handle: [name, or handle if you prefer]
- Role: [current role, optional]
- Background: [2–3 sentences: sectors, environments, scale you have operated at]
- Contact: [GitHub profile / LinkedIn / email — whatever you want public]

This is a personal, community-driven project. It is not affiliated with, endorsed by, or the position of my employer [or: past employers], nor of NIST, ENISA, MITRE, or any authority referenced in it.

## What this project is — and is not

In scope: building and maturing a CDC/SOC for enterprise IT environments — endpoints, servers, identity, cloud/SaaS, enterprise networks — for organisations across the EU.

Explicitly out of scope (for now):

- OT/ICS environments (industrial control systems, SCADA, building automation). OT monitoring, safety-first response and the Purdue-model realities differ fundamentally from IT — applying IT playbooks to OT can be dangerous. An OT extension profile is on the [roadmap](ROADMAP.md).
- Telco core networks (signalling, RAN, lawful intercept environments) — regulated separately in most member states and operationally distinct.
- Defence/classified environments and other regimes with their own mandatory frameworks.

If you work in those domains, the GOVERN and maturity-model thinking still transfers — but treat the technical content (PROTECT/DETECT/RESPOND playbooks) as IT-specific.

## How you can help

Corrections, national annex updates, translations, and above all your own pitfalls — see [CONTRIBUTING.md](CONTRIBUTING.md). If this framework spares your team one of the mistakes above, it has done its job.

[Name/handle], [year]
