# Roadmap

## v0.1 — content-complete (current)
Core framework (six CSF 2.0 functions with CIA mapping, maturity criteria, EU hooks, external-dependency tables) · design layer (start-here prioritisation, E/S/A tiers, operating models incl. MSSP and shared CDCs, ECSF-based roles) · operations layer (tuning, detection-as-code + deep dive, CTI deep dive, automation guardrails, tool discipline) · community layer (RFC 2350, TF-CSIRT/FIRST, SIM3 crosswalk, controls register, annual calendar) · regulatory layer (EU landscape, 27 national annexes, interactive law selector, CIS Controls crosswalk) · practical assets (9 templates, 3 platform playbooks, design navigator, maturity self-assessment).

## v0.2
- [ ] Deepen national annexes to Denmark-level detail (community-driven)
- [ ] Scenario playbooks: ransomware, BEC, identity compromise, data breach
- [ ] Statutory notification report templates (NIS2 early warning, GDPR Art. 33)
- [ ] Build script: generate per-profile Markdown/PDF from law tags
- [ ] Machine-readable maturity assessment (YAML) + scoring script
- [ ] GitHub Actions: link checker for authority URLs

## v0.3
- [ ] Crosswalks: OCDF ↔ ISO/IEC 27001 Annex A ↔ NIS2 Art. 21(2)(a–j) ↔ DORA
- [ ] Non-normative tooling appendix (open source options per capability)
- [ ] First translations (Danish first)

## Later
- [ ] OT/ICS extension profile
- [ ] Cloud-native CDC profile
- [ ] Community maturity benchmark (anonymised)
